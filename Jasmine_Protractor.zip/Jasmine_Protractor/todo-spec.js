﻿// JavaScript source code
describe('todo mvc angular demo', function() {

    beforeEach(function() {
        browser.get('http://todomvc.com/examples/angularjs/#/');
    })


    afterEach(function() {
        browser.executeScript('window.sessionStorage.clear();');
        browser.executeScript('window.localStorage.clear();');
    })

    it('should open the web page', function () {
      //  browser.get('http://todomvc.com/examples/angularjs/#/');

        expect(element(by.id('todo-form')).isDisplayed()).toBeTruthy();

    });
    it('should add item to the list', function() {
        //   browser.get('http://todomvc.com/examples/angularjs/#/');

        var inputField = element(by.model('newTodo')); //.then funkcija iespējama
        inputField.sendKeys('Text from test');
        browser.actions().sendKeys(protractor.Key.ENTER).perform();
        expect(element.all(by.repeater('todo in todos')).count()).toEqual(1)
    });
    //should add multiple items in the list 
    it('should add multiple items in the list', function () {
        var inputField = element(by.model('newTodo')); 
        inputField.sendKeys('Text from test 1');
        browser.actions().sendKeys(protractor.Key.ENTER).perform();

        var inputField = element(by.model('newTodo')); 
        inputField.sendKeys('Text from test 2');
        browser.actions().sendKeys(protractor.Key.ENTER).perform();
        //should show correct count for items left
        expect(element.all(by.repeater('todo in todos')).count()).toEqual(2)
    });
  
    //should filter all active items

    it('should add 2 items to the list, mark one as done', function () {
        var inputField = element(by.model('newTodo')); //.then funkcija iespējama
        inputField.sendKeys('Text from test 3');
        browser.actions().sendKeys(protractor.Key.ENTER).perform();

     //   var inputField = element(by.model('newTodo')); //.then funkcija iespējama
        inputField.sendKeys('Text from test 4');
        browser.actions().sendKeys(protractor.Key.ENTER).perform();

        expect(element.all(by.repeater('todo in todos')).then(function(todo) {
        todo[1].element(by.className('toggle')).click();
         }
        ))
    });

    it('should filter all active items', function () {
        var inputField = element(by.model('newTodo')); //.then funkcija iespējama
        inputField.sendKeys('Jauns uzdevums');
        browser.actions().sendKeys(protractor.Key.ENTER).perform();

        //   var inputField = element(by.model('newTodo')); //.then funkcija iespējama
        inputField.sendKeys('Steidzams uzdevums');
        browser.actions().sendKeys(protractor.Key.ENTER).perform();

        expect(element.all(by.repeater('todo in todos')).then(function (todo) {
        todo[0].element(by.className('toggle')).click();
        }
        ))

     //   expect(element.all(by.id('filters')).then(function() {
        //   element(by.binding('Active')).click();
        //    browser.actions('http://todomvc.com/examples/angularjs/#/active').click();
            //  }))


        });


});





//should add multiple items in the list 
