// JavaScript source code
exports.config = {
    seleniumAddress: 'http://127.0.0.1:4444/wd/hub',
    specs: ['todo-spec.js'],
    onPrepare: function() {
        var specRunReporter = require ('jasmine-spec-reporter');
        jasmine.getEnv().addReporter(new specRunReporter({
            displayStackTrace: 'summary',
            displaySpecDuration: true

        })); 
    }
}