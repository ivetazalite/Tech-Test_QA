Pre-conditions
Please install cucumber-api on your PC (details you can find here -> https://github.com/hidroh/cucumber-api)

To get email format validation you need to update this file <your path to this folder>\cucumber-api\lib\cucumber-api\response.rb  with ...features\response.rb file in this folder 




Run API method automated test:
1. open cmd;
2. redirect where your ruby and cucumber files installed 
3. run this command 

>cucumber -v <add path to fetures folder>\features\api_method_tests.features -c

4. or run this command line , then you will generate execution report in html format

>cucumber -v features\api_method_tests.features -c --format html --out <add path to fetures folder>\features\report.html
