require 'cucumber-api/response'
require 'cucumber-api/steps'
require 'cucumber-api'

Then(/^the JSON response should have "([^"]*)" of type \
(string|number) and value:$/) do |json_path, type, value|
  @response.get_as_type_and_check_value json_path, type, resolve(value)
end



# To use this step
# update method get_as_type
# with this case
# when 'email'
# valid = value =~(/[a-z0-9_.-]+@[a-z0-9-]+\.[a-z.]+/i)



Then(/^the JSON response should have "([^"]*)" of type \
(email) and value "([^"]*)"$/) do |json_path, type, value|
  @response.get_as_type_and_check_value json_path, type, resolve(value)
end


