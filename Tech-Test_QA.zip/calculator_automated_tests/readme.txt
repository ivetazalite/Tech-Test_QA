Pre-conditions
To set your environmet ready for calabash-android autotest execution you can read this page:  

https://github.com/calabash/calabash-android

1. Install all needed applications 
2. Set environment path

ENV["ADB_DEVICE_ARG"], 
ENV["TEST_SERVER_PORT"], 
ENV ["APP_PATH "]
ENV["TEST_APP_PATH"]

3. Copy features in your folder locally 
4. Open application undr test (Assignment1) in Android Studio and run in one of emulators 
5. Update application's AndroidManifest.xtml file by adding   <uses-permission android:name="android.permission.INTERNET" />
6. Cretae test application run 
7. Open cmd  and execute command lines

	-> calabash-android build  <add path to this file location>\Assignment1\app\build\outputs\apk\app-debug.apk 
	-> calabash-android run <add path to this file location>\Assignment1\app\build\outputs\apk\app-debug.apk --format html --out <add path to report folder>\report.html

build - will generate test application 
run - will execute all test scenarios written in calculator.features file 
